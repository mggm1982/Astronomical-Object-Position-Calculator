#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include<cmath>
using namespace std;

  class star {
public:
    string name;
    double ra, dec;
};

  vector<star> astar;
  double lat,lo2,LSTd;


int gif(double x){
    int i = x;
    if(i <= x){
        return i;
    }
    else{
        return (i - 1);
    }
}    

double normalise1(double x){
    while(x < 0){
        x += 360;
    }
    while(x >= 360){
        x -= 360;
    }
    return x;
}    

double normalise2(double x){
    while(x < -180){
        x += 360;
    }
    while(x > 180){
        x -= 360;
    }
        return x;
}    
        
double toRadians(double degrees) {
    return (degrees * 3.14159265358979323846) / 180.0;
}

double toDegrees(double radians) {
    return (radians * 180.0) / 3.14159265358979323846;
}


double ALTITUDE(int k){
    double HA;
    HA = LSTd - astar[k].ra;
    normalise2(HA);

    double latR;
    latR = toRadians(lat);
    double decR;
    decR = toRadians(astar[k].dec);
    double HAr = toRadians(HA);
    double ALTr;
    ALTr = asin(sin(latR)*sin(decR) + cos(latR)*cos(decR)*cos(HAr));
    double ALT = toDegrees(ALTr);
    return ALT;
}


    double AZIMUTH(int k){
    double HA;
    HA = LSTd - astar[k].ra;
    normalise2(HA);

    double latR;
    latR = toRadians(lat);
    double decR;
    decR = toRadians(astar[k].dec);
    double HAr = toRadians(HA);
    double AZIr;
    AZIr = atan2(-sin(HAr)*cos(decR), sin(decR)*cos(latR) - sin(latR)*cos(HAr)*cos(decR));
    double AZId;
    AZId = toDegrees(AZIr);
    double AZI = normalise1(AZId); 
    return AZI;
} 

  
int main(){
    ifstream file("bright_stars_name_radec_deg.txt");
    star a;
    while (file >> a.name >> a.ra >> a.dec) {
        astar.push_back(a);
    }
    file.close();

    cout << "ASTRONOMICAL OBJECT POSITION CALCULATOR"<< endl;
    cout << "Enter the Latitude of your location: ";
    cin >> lat;
    cout << "Enter the Longitude of your location: ";
    cin >> lo2;
    int D,mon,Y;
    cout << "Enter observation date in IST:\nDay Month Year ";
    cin >> D >> mon >> Y;
    int H,min;
    cout <<"Enter time in IST(24-Hour clock).\nHour Minute ";
    cin >> H >> min;
    cout << "What would you like to do? \n";
    cout << "1.Show all the objects above horizon.\n2.Search for ane object" << endl;
    int x;
    cout <<"Enter a choice : ";
    cin >> x;

    double hr = H + min/60.0;
    double UTC;
    UTC = hr - 5.5;
    if(UTC < 0){
        UTC += 24;
        D -= 1; 
    }

    int b = gif((14-mon)/12);
    int y = Y + 4800 - b;
    int m = mon + 12*b - 3;
    double JD;
    JD = D + (365*y) + (UTC/24.0) + gif((153*m + 2)/5) + gif(y/4) + gif(y/400) - gif(y/100) - 32045.5;
    
    double T;
    T = (JD-2451545)/36525;
    double GMST;
    GMST=280.46061837 + 360.98564736629*(JD-2451545.0) + (0.000387933*T*T) - ((T*T*T)/38710000);
    
    GMST = normalise1(GMST);
    LSTd = GMST + lo2;
    LSTd = normalise1(LSTd);
    double LST;
    LST = LSTd/15.0;

    if(x == 1){
     cout << "Objects above horizon at your location are:- \n";
     cout << "Name                      Altitude          Azimuth\n----------------------------------"<<endl;
    for(int i = 0; i < astar.size(); i++){
    if(ALTITUDE(i) > 0){
        cout << astar[i].name<<"                "<<ALTITUDE(i)<<"       "<<AZIMUTH(i)<<endl;
    }
    }
}
    else{
        cout << "Enter the name of the object you are looking for: ";
        string name;
        cin >> name;
        for(int i = 0; i < astar.size(); i++){
            if(name == astar[i].name){
                cout << "Name                   Altitude         Azimuth\n------------------------------------------------"<<endl;
                 cout << astar[i].name<<"                "<<ALTITUDE(i)<<"       "<<AZIMUTH(i)<<endl;
            }
        }
    }
    return 0;
}